﻿using Abp.MultiTenancy;
using FastCourse.Authorization.Users;

namespace FastCourse.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}
