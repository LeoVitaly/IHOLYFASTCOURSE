﻿using Abp.Application.Services;

namespace FastCourse.Certificates
{
    public interface ICertificateAppService : IApplicationService
    {
    }
}
