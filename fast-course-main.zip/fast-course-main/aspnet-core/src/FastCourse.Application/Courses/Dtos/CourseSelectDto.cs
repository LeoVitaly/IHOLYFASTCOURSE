﻿namespace FastCourse.Courses.Dtos
{
    public class CourseSelectDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
