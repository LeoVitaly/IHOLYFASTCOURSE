﻿using Abp.Application.Services;

namespace FastCourse.Questions
{
    public interface IQuestionAppService : IApplicationService
    {
    }
}
