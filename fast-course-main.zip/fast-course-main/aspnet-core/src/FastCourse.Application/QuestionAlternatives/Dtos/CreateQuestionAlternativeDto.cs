﻿namespace FastCourse.QuestionAlternatives.Dtos
{
    public class CreateQuestionAlternativeDto
    {
        public string AlternativeDescription { get; set; }
        public bool IsCorrect { get; set; }
    }
}
