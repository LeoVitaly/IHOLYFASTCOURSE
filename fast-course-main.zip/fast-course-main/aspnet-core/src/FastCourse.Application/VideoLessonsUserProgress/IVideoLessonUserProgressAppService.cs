﻿using Abp.Application.Services;

namespace FastCourse.VideoLessonsUserProgress
{
    public interface IVideoLessonUserProgressAppService : IApplicationService
    {
    }
}
