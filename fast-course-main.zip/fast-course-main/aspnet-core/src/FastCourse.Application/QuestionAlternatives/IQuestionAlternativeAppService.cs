﻿using Abp.Application.Services;

namespace FastCourse.QuestionAlternatives
{
    public interface IQuestionAlternativeAppService : IApplicationService
    {
    }
}
