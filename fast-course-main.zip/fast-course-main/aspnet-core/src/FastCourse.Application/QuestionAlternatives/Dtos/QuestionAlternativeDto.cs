﻿namespace FastCourse.QuestionAlternatives.Dtos
{
    public class QuestionAlternativeDto
    {
        public string AlternativeDescription { get; set; }
        public bool IsCorrect { get; set; }
    }
}
