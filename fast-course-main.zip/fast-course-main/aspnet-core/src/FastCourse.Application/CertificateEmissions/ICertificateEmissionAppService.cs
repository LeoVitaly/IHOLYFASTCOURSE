﻿using Abp.Application.Services;

namespace FastCourse.CertificateEmissions
{
    public interface ICertificateEmissionAppService : IApplicationService
    {
    }
}
