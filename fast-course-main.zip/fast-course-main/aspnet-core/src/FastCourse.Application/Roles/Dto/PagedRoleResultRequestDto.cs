﻿using Abp.Application.Services.Dto;

namespace FastCourse.Roles.Dto
{
    public class PagedRoleResultRequestDto : PagedResultRequestDto
    {
        public string Keyword { get; set; }
    }
}

