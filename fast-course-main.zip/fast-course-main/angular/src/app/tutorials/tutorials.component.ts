import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tutorials',
  templateUrl: './tutorials.component.html'
})
export class TutorialsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
