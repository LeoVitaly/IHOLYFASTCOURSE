﻿using Abp.Application.Services;

namespace FastCourse.VideoLessons
{
    public interface IVideoLessonAppService : IApplicationService
    {
    }
}
